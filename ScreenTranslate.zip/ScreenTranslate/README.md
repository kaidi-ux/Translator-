# Traductor de pantalla (Android)

Burbuja flotante: la tocas en cualquier app y traduce el texto de la pantalla
(OCR + traducción en el dispositivo con ML Kit), dibujando la traducción encima.

## Compilar
1. Instala Android Studio (versión reciente, con JDK 17).
2. File > Open y elige esta carpeta. Espera a que termine el Gradle Sync.
3. Conecta un móvil Android (8.0 o superior) con depuración USB y pulsa Run.

## Usar
1. Abre la app, elige idioma de origen y destino, pulsa **Iniciar**.
2. Concede "Mostrar sobre otras apps" (la primera vez) y vuelve a pulsar Iniciar.
3. En el aviso de captura de pantalla elige **Toda la pantalla** (no "una sola app").
4. Abre cualquier app y toca la burbuja. Toca la traducción para cerrarla.
5. Para parar: botón Detener o la notificación.

## Notas
- La primera vez necesita internet para bajar el modelo de traducción (unos 30 MB por idioma). Después funciona sin conexión.
- Apps que bloquean capturas (banca, DRM, etc.) saldrán en negro y no se podrán traducir.
- Si giras el móvil (por ejemplo, en un juego horizontal), la captura se ajusta sola.
