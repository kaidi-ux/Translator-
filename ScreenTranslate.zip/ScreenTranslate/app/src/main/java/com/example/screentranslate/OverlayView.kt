package com.example.screentranslate

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

data class Item(val box: Rect, val text: String)

/** Dibuja la traducción encima de cada bloque de texto detectado. */
class OverlayView(context: Context, private val items: List<Item>) : View(context) {

    private val bg = Paint().apply { color = 0xF2111111.toInt() }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val dp = resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        for (item in items) {
            val r = item.box
            canvas.drawRect(r, bg)
            val width = maxOf(r.width(), 1)
            var size = minOf(r.height().toFloat(), 40 * dp)
            var layout: StaticLayout
            while (true) {
                tp.textSize = size
                layout = StaticLayout.Builder.obtain(item.text, 0, item.text.length, tp, width).build()
                if (layout.height <= r.height() || size <= 9 * dp) break
                size -= dp
            }
            canvas.save()
            canvas.clipRect(r)
            canvas.translate(r.left.toFloat(), r.top.toFloat())
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
