package com.example.screentranslate

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

class ScreenTranslateService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_SRC = "src"
        const val EXTRA_TGT = "tgt"
        const val ACTION_STOP = "com.example.screentranslate.STOP"
        private const val CHANNEL = "screen_translate"
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var projection: MediaProjection? = null
    private var projCallback: MediaProjection.Callback? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var latest: Image? = null
    private var recognizer: TextRecognizer? = null
    private var translator: Translator? = null
    private var bubble: View? = null
    private var overlay: View? = null
    private var busy = false
    private var w = 0
    private var h = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        cleanup()
        startForegroundNow()

        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        val src = Langs.source[intent.getIntExtra(EXTRA_SRC, 0)]
        val tgt = Langs.target[intent.getIntExtra(EXTRA_TGT, 0)]

        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data)
        projCallback = object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }
        projection?.registerCallback(projCallback!!, main)

        startCapture()

        recognizer = when (src.script) {
            Script.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            Script.CHINESE -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
            Script.JAPANESE -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
            Script.KOREAN -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        }
        translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(src.code)
                .setTargetLanguage(tgt.code)
                .build()
        )
        // Descarga el modelo de traducción la primera vez (necesita internet)
        scope.launch {
            try {
                translator?.downloadModelIfNeeded(DownloadConditions.Builder().build())?.await()
            } catch (e: Exception) {
                toast("No se pudo descargar el modelo de traducción. Revisa tu conexión.")
            }
        }

        showBubble()
        return START_NOT_STICKY
    }

    // ---------- Servicio en primer plano ----------

    private fun startForegroundNow() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Traductor de pantalla", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenTranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setContentTitle("Traductor de pantalla activo")
            .setContentText("Toca la burbuja para traducir")
            .addAction(0, "Detener", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        )
    }

    // ---------- Captura de pantalla ----------

    private fun realMetrics(): DisplayMetrics {
        val m = DisplayMetrics()
        getSystemService(DisplayManager::class.java)
            .getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return m
    }

    private fun newReader(): ImageReader {
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = rd.acquireLatestImage() ?: return@setOnImageAvailableListener
            latest?.close()
            latest = img
        }, main)
        return r
    }

    private fun startCapture() {
        val m = realMetrics()
        w = m.widthPixels
        h = m.heightPixels
        val r = newReader()
        reader = r

        // En Android 14+ solo se puede crear UN VirtualDisplay por proyección:
        // se crea una vez y se reutiliza.
        display = projection!!.createVirtualDisplay(
            "screen-translate", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
    }

    /** Si el móvil giró (vertical/horizontal), ajusta la captura. Devuelve true si cambió. */
    private fun adaptToRotation(): Boolean {
        val m = realMetrics()
        if (m.widthPixels == w && m.heightPixels == h) return false
        w = m.widthPixels
        h = m.heightPixels
        latest?.close()
        latest = null
        val old = reader
        val r = newReader()
        reader = r
        display?.resize(w, h, m.densityDpi)
        display?.surface = r.surface
        old?.close()
        return true
    }

    private fun capture() {
        if (busy) return
        busy = true
        bubble?.visibility = View.INVISIBLE  // que la burbuja no salga en la captura
        val rotated = adaptToRotation()
        main.postDelayed({ grab() }, if (rotated) 600L else 250L)
    }

    private fun grab() {
        val img = latest
        if (img == null) {
            toast("Aún no hay imagen de la pantalla. Inténtalo de nuevo.")
            finishCapture()
            return
        }
        val plane = img.planes[0]
        plane.buffer.rewind()
        val rowPadding = plane.rowStride - plane.pixelStride * w
        val full = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        val bmp = Bitmap.createBitmap(full, 0, 0, w, h)
        translate(bmp)
    }

    // ---------- OCR + traducción ----------

    private fun translate(bmp: Bitmap) {
        scope.launch {
            try {
                val rec = recognizer
                val tr = translator
                if (rec == null || tr == null) { finishCapture(); return@launch }

                val result = rec.process(InputImage.fromBitmap(bmp, 0)).await()
                val blocks = result.textBlocks.mapNotNull { b ->
                    b.boundingBox?.let { box -> box to b.text.replace('\n', ' ') }
                }
                if (blocks.isEmpty()) {
                    toast("No encontré texto en la pantalla.")
                    finishCapture()
                    return@launch
                }
                tr.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
                val items = coroutineScope {
                    blocks.map { (box, text) ->
                        async { Item(box, tr.translate(text).await()) }
                    }.awaitAll()
                }
                showOverlay(items)
            } catch (e: Exception) {
                toast("Error: ${e.localizedMessage}")
                finishCapture()
            }
        }
    }

    // ---------- Interfaz flotante ----------

    private fun showBubble() {
        val size = (56 * resources.displayMetrics.density).toInt()
        val tv = TextView(this).apply {
            text = "文A"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF1565C0.toInt())
            }
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 300
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    if (moved) {
                        lp.x = startX + dx
                        lp.y = startY + dy
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) capture()
            }
            true
        }
        wm.addView(tv, lp)
        bubble = tv
    }

    private fun showOverlay(items: List<Item>) {
        val v = OverlayView(this, items)
        v.setOnClickListener { dismissOverlay() }  // toca para cerrar
        val lp = WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(v, lp)
        overlay = v
    }

    private fun dismissOverlay() {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        finishCapture()
    }

    private fun finishCapture() {
        bubble?.visibility = View.VISIBLE
        busy = false
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- Limpieza ----------

    private fun cleanup() {
        bubble?.let { runCatching { wm.removeView(it) } }; bubble = null
        overlay?.let { runCatching { wm.removeView(it) } }; overlay = null
        display?.release(); display = null
        latest?.close(); latest = null
        reader?.close(); reader = null
        projCallback?.let { projection?.unregisterCallback(it) }
        projCallback = null
        projection?.stop(); projection = null
        recognizer?.close(); recognizer = null
        translator?.close(); translator = null
        busy = false
    }

    override fun onDestroy() {
        cleanup()
        scope.cancel()
        super.onDestroy()
    }
}
