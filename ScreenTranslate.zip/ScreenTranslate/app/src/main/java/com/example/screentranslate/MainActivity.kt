package com.example.screentranslate

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var srcSpinner: Spinner
    private lateinit var tgtSpinner: Spinner

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenTranslateService::class.java).apply {
                    putExtra(ScreenTranslateService.EXTRA_CODE, r.resultCode)
                    putExtra(ScreenTranslateService.EXTRA_DATA, data)
                    putExtra(ScreenTranslateService.EXTRA_SRC, srcSpinner.selectedItemPosition)
                    putExtra(ScreenTranslateService.EXTRA_TGT, tgtSpinner.selectedItemPosition)
                }
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(this, "Listo. Abre otra app y toca la burbuja.", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            }
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { requestProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply { text = "Traductor de pantalla"; textSize = 24f })

        root.addView(TextView(this).apply { text = "\nIdioma del texto en pantalla" })
        srcSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                Langs.source.map { it.label }
            )
        }
        root.addView(srcSpinner)

        root.addView(TextView(this).apply { text = "\nTraducir a" })
        tgtSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                Langs.target.map { it.label }
            )
        }
        root.addView(tgtSpinner)

        root.addView(Button(this).apply {
            text = "Iniciar"
            setOnClickListener { onStartClicked() }
        })
        root.addView(Button(this).apply {
            text = "Detener"
            setOnClickListener { stopService(Intent(this@MainActivity, ScreenTranslateService::class.java)) }
        })
        setContentView(root)
    }

    private fun onStartClicked() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this, "Activa «Mostrar sobre otras apps» y vuelve a pulsar Iniciar.", Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestProjection()
        }
    }

    private fun requestProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
