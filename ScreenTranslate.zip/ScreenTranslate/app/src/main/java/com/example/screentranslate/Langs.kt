package com.example.screentranslate

import com.google.mlkit.nl.translate.TranslateLanguage

enum class Script { LATIN, CHINESE, JAPANESE, KOREAN }

data class Lang(val label: String, val code: String, val script: Script = Script.LATIN)

object Langs {
    // Idioma del texto que aparece en pantalla
    val source = listOf(
        Lang("Inglés", TranslateLanguage.ENGLISH),
        Lang("Francés", TranslateLanguage.FRENCH),
        Lang("Alemán", TranslateLanguage.GERMAN),
        Lang("Italiano", TranslateLanguage.ITALIAN),
        Lang("Portugués", TranslateLanguage.PORTUGUESE),
        Lang("Chino", TranslateLanguage.CHINESE, Script.CHINESE),
        Lang("Japonés", TranslateLanguage.JAPANESE, Script.JAPANESE),
        Lang("Coreano", TranslateLanguage.KOREAN, Script.KOREAN),
    )

    // Idioma al que quieres traducir
    val target = listOf(
        Lang("Español", TranslateLanguage.SPANISH),
        Lang("Inglés", TranslateLanguage.ENGLISH),
        Lang("Francés", TranslateLanguage.FRENCH),
        Lang("Alemán", TranslateLanguage.GERMAN),
        Lang("Italiano", TranslateLanguage.ITALIAN),
        Lang("Portugués", TranslateLanguage.PORTUGUESE),
    )
}
